package com.hdfc.utils;
//package com.udan.utils;
//
//import java.io.File;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//
//public class Test {
//
//	public static void main(String[] args) {
//		
//		String filePath = "hello3.txt";
//		File file = new File(filePath);
//		String filePath1 = file.getPath();
//		String filePath2 = file.getAbsolutePath();
//		System.out.println("filePath1 : " + filePath1);
//		System.out.println("filePath2 : " + filePath2);
//		
//		file.delete();
////		Path path2 = Paths.get("hello.txt");
////	    System.out.println("path : " + path2);
//	}
//
//	
//	
//}
